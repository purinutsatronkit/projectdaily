ฟอนต์สำหรับสไลด์ TaskFlow

ใช้เมื่อ PowerPoint แสดงฟอนต์ต่างจากภาพตัวอย่าง:
1. แตก ZIP นี้
2. คลิกขวาไฟล์ .ttf ทั้ง 4 ไฟล์ แล้วเลือก Install / ติดตั้ง
3. ปิดและเปิด PowerPoint ใหม่

ชื่อ family ใน PowerPoint:
- IBM Plex Sans Thai (Regular และ Bold)
- Inter 18pt (Regular และ Bold)

ฟอนต์มาจาก Google Fonts และแจกจ่ายพร้อมใบอนุญาต SIL Open Font License ใน ZIP นี้
แหล่งไฟล์ IBM: https://github.com/google/fonts/tree/main/ofl/ibmplexsansthai
แหล่งไฟล์ Inter: https://fonts.googleapis.com/css2?family=Inter:opsz,wght@18,400;18,700

ไม่จำเป็นต้องติดตั้งหากเครื่องมีฟอนต์เหล่านี้อยู่แล้ว หรือใช้โปรแกรมที่มีฟอนต์ให้เลือกอยู่แล้ว
